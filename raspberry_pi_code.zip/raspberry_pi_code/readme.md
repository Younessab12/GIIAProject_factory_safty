This is a beta version that works on raspberry pi 4, we are working on a docker version that can be shipped and tested everywhere
